.. code:: ipython3

    import matplotlib.pyplot as plt

.. code:: ipython3

    import pandas as pd

.. code:: ipython3

    %matplotlib inline

.. code:: ipython3

    df = pd.read_csv('C:\Family Business 3\Family Business 3.csv')

.. code:: ipython3

    df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Family Business</th>
          <th>No of People Manges the Business</th>
          <th>Annual income Of the Business is:</th>
          <th>Relation</th>
          <th>Names</th>
          <th>No of Employess</th>
          <th>Name of the Employees</th>
          <th>Employes Salary per Month/day</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1)Fruit Gardens.</td>
          <td>2</td>
          <td>Between 15 lakh-20lakh</td>
          <td>Paternal Elder Uncle And Younger uncle</td>
          <td>Ram</td>
          <td>Minimum 40-80 Part Time Employee</td>
          <td>…...</td>
          <td>500/D</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2)Grocery Shop</td>
          <td>1</td>
          <td>60-80 lakh</td>
          <td>Elder Brother</td>
          <td>Vikas</td>
          <td>3</td>
          <td>1)kiran,2)Teju,3)Karan</td>
          <td>17000/M</td>
        </tr>
        <tr>
          <th>2</th>
          <td>3)Vegetable Shop</td>
          <td>1</td>
          <td>3 lakhs</td>
          <td>Elder sister</td>
          <td>Spoorthi</td>
          <td>1</td>
          <td>1)Mounika</td>
          <td>7000/M</td>
        </tr>
        <tr>
          <th>3</th>
          <td>4)Movie Theaters</td>
          <td>2</td>
          <td>50-70 lakh</td>
          <td>Paternal younger Uncle</td>
          <td>Shivu</td>
          <td>6</td>
          <td>1)Shambu, 2)Shankar, 3)Somu, 4)Shekhar, 5)Mohi...</td>
          <td>16000/M</td>
        </tr>
        <tr>
          <th>4</th>
          <td>5)Flower Shop</td>
          <td>2</td>
          <td>6lakhs</td>
          <td>Two younger Sister</td>
          <td>Nandini &amp; Keerthi</td>
          <td>2</td>
          <td>1)Soumya, 2)Sangeetha</td>
          <td>7000/M</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 7 entries, 0 to 6
    Data columns (total 8 columns):
     #   Column                             Non-Null Count  Dtype 
    ---  ------                             --------------  ----- 
     0   Family Business                    7 non-null      object
     1   No of People Manges the Business   7 non-null      int64 
     2   Annual income Of the Business is:  7 non-null      object
     3   Relation                           7 non-null      object
     4   Names                              7 non-null      object
     5   No of Employess                    7 non-null      object
     6   Name of the Employees              7 non-null      object
     7   Employes Salary per Month/day      7 non-null      object
    dtypes: int64(1), object(7)
    memory usage: 580.0+ bytes
    

.. code:: ipython3

    df.tail()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Family Business</th>
          <th>No of People Manges the Business</th>
          <th>Annual income Of the Business is:</th>
          <th>Relation</th>
          <th>Names</th>
          <th>No of Employess</th>
          <th>Name of the Employees</th>
          <th>Employes Salary per Month/day</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>2</th>
          <td>3)Vegetable Shop</td>
          <td>1</td>
          <td>3 lakhs</td>
          <td>Elder sister</td>
          <td>Spoorthi</td>
          <td>1</td>
          <td>1)Mounika</td>
          <td>7000/M</td>
        </tr>
        <tr>
          <th>3</th>
          <td>4)Movie Theaters</td>
          <td>2</td>
          <td>50-70 lakh</td>
          <td>Paternal younger Uncle</td>
          <td>Shivu</td>
          <td>6</td>
          <td>1)Shambu, 2)Shankar, 3)Somu, 4)Shekhar, 5)Mohi...</td>
          <td>16000/M</td>
        </tr>
        <tr>
          <th>4</th>
          <td>5)Flower Shop</td>
          <td>2</td>
          <td>6lakhs</td>
          <td>Two younger Sister</td>
          <td>Nandini &amp; Keerthi</td>
          <td>2</td>
          <td>1)Soumya, 2)Sangeetha</td>
          <td>7000/M</td>
        </tr>
        <tr>
          <th>5</th>
          <td>6)Photo Studio</td>
          <td>2</td>
          <td>6 lakhs</td>
          <td>Younger Brother</td>
          <td>Mohan</td>
          <td>3</td>
          <td>1)David, 2)Vikram, 3)Nabi</td>
          <td>6000/M</td>
        </tr>
        <tr>
          <th>6</th>
          <td>7)Car Mechanic</td>
          <td>3</td>
          <td>10-12 lakh</td>
          <td>Friends And brother(Joint Business)</td>
          <td>Anand,Arun,Abhishek</td>
          <td>8</td>
          <td>1)Surya, 2)Chandru, 3)Hanumanthappa, 4)Advik, ...</td>
          <td>16500/M</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    data=pd.DataFrame(df)

.. code:: ipython3

    data




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Family Business</th>
          <th>No of People Manges the Business</th>
          <th>Annual income Of the Business is:</th>
          <th>Relation</th>
          <th>Names</th>
          <th>No of Employess</th>
          <th>Name of the Employees</th>
          <th>Employes Salary per Month/day</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1)Fruit Gardens.</td>
          <td>2</td>
          <td>Between 15 lakh-20lakh</td>
          <td>Paternal Elder Uncle And Younger uncle</td>
          <td>Ram</td>
          <td>Minimum 40-80 Part Time Employee</td>
          <td>…...</td>
          <td>500/D</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2)Grocery Shop</td>
          <td>1</td>
          <td>60-80 lakh</td>
          <td>Elder Brother</td>
          <td>Vikas</td>
          <td>3</td>
          <td>1)kiran,2)Teju,3)Karan</td>
          <td>17000/M</td>
        </tr>
        <tr>
          <th>2</th>
          <td>3)Vegetable Shop</td>
          <td>1</td>
          <td>3 lakhs</td>
          <td>Elder sister</td>
          <td>Spoorthi</td>
          <td>1</td>
          <td>1)Mounika</td>
          <td>7000/M</td>
        </tr>
        <tr>
          <th>3</th>
          <td>4)Movie Theaters</td>
          <td>2</td>
          <td>50-70 lakh</td>
          <td>Paternal younger Uncle</td>
          <td>Shivu</td>
          <td>6</td>
          <td>1)Shambu, 2)Shankar, 3)Somu, 4)Shekhar, 5)Mohi...</td>
          <td>16000/M</td>
        </tr>
        <tr>
          <th>4</th>
          <td>5)Flower Shop</td>
          <td>2</td>
          <td>6lakhs</td>
          <td>Two younger Sister</td>
          <td>Nandini &amp; Keerthi</td>
          <td>2</td>
          <td>1)Soumya, 2)Sangeetha</td>
          <td>7000/M</td>
        </tr>
        <tr>
          <th>5</th>
          <td>6)Photo Studio</td>
          <td>2</td>
          <td>6 lakhs</td>
          <td>Younger Brother</td>
          <td>Mohan</td>
          <td>3</td>
          <td>1)David, 2)Vikram, 3)Nabi</td>
          <td>6000/M</td>
        </tr>
        <tr>
          <th>6</th>
          <td>7)Car Mechanic</td>
          <td>3</td>
          <td>10-12 lakh</td>
          <td>Friends And brother(Joint Business)</td>
          <td>Anand,Arun,Abhishek</td>
          <td>8</td>
          <td>1)Surya, 2)Chandru, 3)Hanumanthappa, 4)Advik, ...</td>
          <td>16500/M</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    fig = plt.figure()



.. parsed-literal::

    <Figure size 640x480 with 0 Axes>


.. code:: ipython3

    fig = plt.figure()
    ax = fig.add_axes([0,0,1.5,1.5])
    x=list(data.iloc[:,0])
    y=list(data.iloc[:,7])
    ax.bar(x,y,color= 'b')
    plt.title('Family Business Names And Employees Name')
    plt.xlabel('Family Business Names')
    plt.ylabel('Name of the Employees')
    plt.show()



.. image:: output_10_0.png


.. code:: ipython3

    x=df['Family Business']
    y=df['Employes Salary per Month/day']

.. code:: ipython3

    plt.xlabel('Family Business', fontsize=11)
    plt.ylabel('Employes Salary per Month/day', fontsize=11)
    plt.bar(x,y)




.. parsed-literal::

    <BarContainer object of 7 artists>




.. image:: output_12_1.png


.. code:: ipython3

    fig = plt.figure()



.. parsed-literal::

    <Figure size 640x480 with 0 Axes>


.. code:: ipython3

    x=pd.array([35,25,25,15,15])
    mylabels= ["Fruit","Vegetabels","grocery","Movie Theaters","Flower shop"]
    myexplode= [0.2,0,0,0,0]
    
    plt.pie(x, labels =mylabels, explode=myexplode, shadow=True)
    plt.legend(title="four business:")
    plt.show()



.. image:: output_14_0.png


.. code:: ipython3

    x=list(data.iloc[:,0])
    y=list(data.iloc[:,7])
    plt.xlabel('Family Business', fontsize=16)
    plt.ylabel('Employes Salary per Month/day', fontsize=18)
    plt.scatter(x, y)
    #plt.plot(x, y)
    plt.show()



.. image:: output_15_0.png


.. code:: ipython3

    x=list(data.iloc[:,0])
    y=list(data.iloc[:,7])
    plt.xlabel('Family Business', fontsize=18)
    plt.ylabel('Employes Salary per Month/day', fontsize=16)
    plt.scatter(x, y)
    plt.plot(x, y)
    plt.show()



.. image:: output_16_0.png


.. code:: ipython3

    x=list(data.iloc[:,0])
    y=list(data.iloc[:,7])
    plt.xlabel('Family Business', fontsize=18)
    plt.ylabel('Employes Salary per Month/day', fontsize=16)
    plt.plot(x, y)
    plt.show()
    



.. image:: output_17_0.png


